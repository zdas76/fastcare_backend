export const UserSearchAbleFields: string[] = ["email, userName"];

export const UserfiltersFields: string[] = [
  "name",
  "email",
  "role",
  "status",
  "searchTerm",
];
