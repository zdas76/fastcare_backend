import prisma from "../../shared/prisma";

const getAllMpoTransection = async (payload: {
  startDate: string;
  endDate: string;
}) => {
  if (payload.endDate) {
    payload.endDate = new Date(
      new Date(payload.endDate).setHours(23, 59, 59, 999),
    ).toISOString();
  }
  const getMOPs = await prisma.user.findMany({
    where: {
      roles: { array_contains: "MPO" },
      status: "ACTIVE",
    },
    select: {
      id: true,
      employeeId: true,
      name: true,
      email: true,
      roles: true,
      status: true,
    },
  });

  const mpoTransectionData = [];

  for (const mpo of getMOPs) {
    const scop = await prisma.scope.findFirst({
      where: {
        employeeId: mpo.employeeId,
      },
      include: {
        chemist: true,
      },
    });

    // Get the current date
    const today = new Date();

    const firstDay = new Date(
      Date.UTC(today.getFullYear(), today.getMonth(), 1),
    );

    const chemistIds = scop?.chemist.map((c) => c.chemistId) || [];

    const transections = await prisma.journal.aggregate({
      _sum: { debitAmount: true, creditAmount: true },
      where: {
        transactionInfo: {
          chemistId: { in: chemistIds },
        },
        date: {
          gte: payload.startDate ? new Date(payload.startDate) : firstDay,
          lte: payload.endDate ? new Date(payload.endDate) : new Date(),
        },
      },
    });

    mpoTransectionData.push({
      mpo,
      transections,
    });

    // const transections = await prisma.transection.AggregateChemist({
    //   where: {},
    // });
  }

  return mpoTransectionData;
};

export const ReportService = {
  getAllMpoTransection,
};
