import { VoucherType } from "../../../../generated/prisma";
import prisma from "../../shared/prisma";
import { DateRangeFilter } from "./report.controllers";

const getAllMpoTransection = async (payload: {
  startDate: string;
  endDate: string;
}) => {
  if (payload.endDate) {
    payload.endDate = new Date(
      new Date(payload.endDate).setHours(23, 59, 59, 999),
    ).toISOString();
  }
  const getMOPs = await prisma.user.findMany({
    where: {
      roles: { array_contains: "MPO" },
      status: "ACTIVE",
    },
    select: {
      id: true,
      employeeId: true,
      name: true,
      email: true,
      roles: true,
      status: true,
    },
  });

  const mpoTransectionData = [];

  for (const mpo of getMOPs) {
    const scop = await prisma.scope.findFirst({
      where: {
        employeeId: mpo.employeeId,
      },
      include: {
        chemist: { select: { chemistId: true } },
      },
    });

    // Get the current date
    const today = new Date();

    const firstDay = new Date(
      Date.UTC(today.getFullYear(), today.getMonth(), 1),
    );

    const chemistIds = scop?.chemist.map((c: any) => c.chemistId) || [];

    const ledgerHeadId = await prisma.ledgerHead.findFirst({
      where: {
        ledgerName: {
          contains: "accounts receivable",
        },
      },
    });

    if (!ledgerHeadId) {
      throw new Error("Ledger head not found");
    }

    const transections = await prisma.journal.aggregate({
      _sum: { debitAmount: true, creditAmount: true },
      where: {
        transactionInfo: {
          is: {
            chemistId: { in: chemistIds },
          },
        },
        ledgerHeadId: ledgerHeadId?.id,
        date: {
          gte: payload.startDate ? new Date(payload.startDate) : firstDay,
          lte: payload.endDate ? new Date(payload.endDate) : new Date(),
        },
      },
    });

    mpoTransectionData.push({
      mpo,
      transections,
    });

    // const transections = await prisma.transection.AggregateChemist({
    //   where: {},
    // });
  }

  return mpoTransectionData;
};

const getMpoReportByEmployeeId = async (
  employeeId: string,
  filters: DateRangeFilter,
) => {
  const { startDate, endDate } = filters;

  // Scope
  const scope = await prisma.scope.findFirst({
    where: { employeeId },
    include: {
      chemist: { select: { chemistId: true } },
    },
  });

  // MPO info
  const mpo = await prisma.user.findFirst({
    where: { employeeId },
    select: {
      id: true,
      employeeId: true,
      name: true,
      email: true,
      status: true,
      roles: true,
    },
  });

  if (!scope || !mpo) {
    throw new Error("MPO or Scope not found");
  }

  // Default dates
  const today = new Date();
  const firstDayOfMonth = new Date(
    Date.UTC(today.getFullYear(), today.getMonth(), 1),
  );

  const fromDate = startDate ? new Date(startDate) : firstDayOfMonth;
  const toDate = endDate ? new Date(endDate) : today;

  const chemistIds = scope.chemist.map((c) => c.chemistId);

  // Ledger head
  const ledgerHead = await prisma.ledgerHead.findFirst({
    where: {
      ledgerName: {
        contains: "accounts receivable",
      },
    },
  });

  if (!ledgerHead) {
    throw new Error("Ledger head not found");
  }

  // Transactions per chemist
  const transactions = await Promise.all(
    chemistIds.map(async (chemistId) => {
      const totals = await prisma.journal.aggregate({
        _sum: {
          debitAmount: true,
          creditAmount: true,
        },
        where: {
          ledgerHeadId: ledgerHead.id,
          transactionInfo: {
            chemistId,
          },
          date: {
            gte: fromDate,
            lte: toDate,
          },
        },
      });

      const chemist = await prisma.chemist.findFirst({
        where: { chemistId },
        select: {
          pharmacyName: true,
          openingDate: true,
          openingDueAmount: true,
        },
      });

      if (!chemist) {
        throw new Error("Chemist not found");
      }

      const dueStart = chemist?.openingDate;
      const dueEnd = new Date(fromDate.getTime() - 24 * 60 * 60 * 1000); // Subtract one day

      const prev_due = await prisma.journal.aggregate({
        _sum: {
          debitAmount: true,
          creditAmount: true,
        },
        where: {
          ledgerHeadId: ledgerHead.id,
          transactionInfo: {
            chemistId,
          },
          date: {
            gte: dueStart,
            lte: dueEnd,
          },
        },
      });

      const salseReturn = await prisma.journal.aggregate({
        _sum: {
          debitAmount: true,
          creditAmount: true,
        },
        where: {
          ledgerHeadId: ledgerHead.id,
          transactionInfo: {
            chemistId,
            voucherType: VoucherType.SALES_RETURN,
          },
          date: {
            gte: fromDate,
            lte: toDate,
          },
        },
      });

      const debit = totals._sum.debitAmount ?? 0;
      const credit = totals._sum.creditAmount ?? 0;
      const prev_debit = prev_due._sum.debitAmount ?? 0;
      const prev_credit = prev_due._sum.creditAmount ?? 0;

      const salesReturn =
        (salseReturn?._sum?.creditAmount ?? 0) -
        (salseReturn?._sum?.debitAmount ?? 0) || 0;

      return {
        chemistId,
        chemist,
        debit,
        credit,
        balance: debit - credit,
        salesReturn,
        prev_due: prev_debit - prev_credit,
      };
    }),
  );

  return {
    mpo,
    transactions,
  };
};


const getAllMpoProgressReport = async ({
  startDate,
  endDate,
}: {
  startDate?: string;
  endDate?: string;
}) => {
  let fromDate: Date;
  let toDate: Date;

  const today = new Date();
  const firstDayOfMonth = new Date(
    Date.UTC(today.getFullYear(), today.getMonth(), 1),
  );

  fromDate = startDate ? new Date(startDate) : firstDayOfMonth;
  if (endDate) {
    toDate = new Date(new Date(endDate).setHours(23, 59, 59, 999));
  } else {
    toDate = today;
  }


  const getMPO = await prisma.user.findMany({
    where: {
      roles: { array_contains: "MPO" },
      status: "ACTIVE",
    },
    select: {
      id: true,
      employeeId: true,
      name: true,
      email: true,
      roles: true,
      status: true,
    },
  });

  const mpoProgressReport = [];

  for (const mpo of getMPO) {
    const scope = await prisma.scope.findFirst({
      where: {
        employeeId: mpo.employeeId,
      },
      include: {
        chemist: { select: { chemistId: true } },
      },
    });

    if (!scope) {
      throw new Error("Scope not found");
    }

    const target = await prisma.mpoTarget.findFirst({
      where: {
        employeeId: mpo.employeeId,
      },
    });

    const chemistIds = scope?.chemist.map((c: any) => c.chemistId) || [];



    // Ledger head
    const ledgerHead = await prisma.ledgerHead.findFirst({
      where: {
        ledgerName: {
          contains: "accounts receivable",
        },
      },
    });

    if (!ledgerHead) {
      throw new Error("Ledger head not found");
    }

    const transections = await prisma.journal.aggregate({
      _sum: { debitAmount: true, creditAmount: true },
      where: {
        transactionInfo: {
          is: {
            chemistId: { in: chemistIds },
          },
        },
        ledgerHeadId: ledgerHead.id,
        date: {
          gte: fromDate,
          lte: toDate,
        },
      },
    });

    mpoProgressReport.push({
      mpo,
      target,
      transections,
    });
  }

  return mpoProgressReport;
};

export const ReportManagementService = {
  getAllMpoTransection,
  getMpoReportByEmployeeId,
  getAllMpoProgressReport
};
