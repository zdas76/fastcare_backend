import express from "express";
import { ReportManagementControllers } from "./report.controllers";

const route = express.Router();

route.get("/mpo_report", ReportManagementControllers.geMpoTransectionReport);

// route.get("/voucher_report/:voucherNo", ReportControllers.getVoucherById);

export const ReportManagementRouter = route;
