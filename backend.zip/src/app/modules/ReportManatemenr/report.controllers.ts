import { StatusCodes } from "http-status-codes";
import catchAsync from "../../shared/catchAsync";
import sendResponse from "../../shared/sendResponse";
import { ReportService } from "./report.service";

const geMpoTransectionReport = catchAsync(async (req, res) => {
  const startDate = req.query.startDate as string;
  const endDate = req.query.endDate as string;

  const result = await ReportService.getAllMpoTransection({
    startDate,
    endDate,
  });

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Last voucher No. retrived Successfully",
    data: result,
  });
});

// const getVoucherById = catchAsync(async (req, res) => {
//   const voucherNo = req.params.voucherNo as string;

//   const result = await ReportService.getReportByVoucherNo(voucherNo);

//   sendResponse(res, {
//     statusCode: StatusCodes.OK,
//     success: true,
//     message: "Vouchers retrived Successfully by Voucher No.",
//     data: result,
//   });
// });

export const ReportManagementControllers = {
  geMpoTransectionReport,
  // getVoucherById,
};
