export const PartySearchAbleFields: string[] = ["name", "contact"];

export const partyfiltersFields: string[] = ["partyType", "searchTerm"];
