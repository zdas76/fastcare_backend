import { BankAccount } from "../../../../generated/prisma/client";

import { StatusCodes } from "http-status-codes";
import AppError from "../../errors/AppError";
import prisma from "../../shared/prisma";

const getAllTransaction = async () => {
  const result = await prisma.bankTransaction.findMany({
    include: {
      bankAccount: true,
    },
  });

  return result;
};

const getTransactionById = async (id: number) => {
  const result = await prisma.bankTransaction.findFirst({
    where: { id },
    include: {
      bankAccount: true,
    },
  });

  return result;
};

const updateTransactionInfo = async (
  id: number,
  payload: Partial<BankAccount>
) => {
  //check account number isExisted
  const accountExisted = await prisma.bankTransaction.findFirst({
    where: { id },
  });

  if (!accountExisted) {
    throw new AppError(StatusCodes.BAD_REQUEST, "No Account Found");
  }

  const result = await prisma.bankTransaction.update({
    where: { id },
    data: payload,
  });

  return result;
};

export const BankTransactionService = {
  getAllTransaction,
  getTransactionById,
  updateTransactionInfo,
};
