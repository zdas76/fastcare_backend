import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import catchAsync from "../../shared/catchAsync";
import sendResponse from "../../shared/sendResponse";
import { ProductService } from "./product.service";

const createProduct = catchAsync(async (req: Request, res: Response) => {
  const result = await ProductService.createProduct(req.body);

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Product create successfully",
    data: result,
  });
});

const getAllProduct = catchAsync(async (req: Request, res: Response) => {
  const result = await ProductService.getProduct();

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Producties retrives successfully",
    data: result,
  });
});

const getProductById = catchAsync(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id!);

  const result = await ProductService.getProductById(id);

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Product retrives successfully",
    data: result,
  });
});

const updateProductById = catchAsync(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id!);

  const result = await ProductService.updateProductById(id, req.body);

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Product update successfully",
    data: result,
  });
});

const deleteProductById = catchAsync(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id!);

  const result = await ProductService.deleteProductById(id);

  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: "Product delete successfully",
    data: result,
  });
});

export const ProductControllers = {
  createProduct,
  getAllProduct,
  getProductById,
  updateProductById,
  deleteProductById,
};
