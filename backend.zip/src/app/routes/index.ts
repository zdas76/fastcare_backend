import express from "express";
import { AccountHeadRoute } from "../modules/accountHead/head.route";
import { AuthRoutes } from "../modules/Auth/auth.router";
import { CategoryRouter } from "../modules/Category/category.route";
import { ChemistRoute } from "../modules/Chemist/chemist.route";
import { DegreeRouter } from "../modules/Degree/degree.route";
import { DepoRouter } from "../modules/Depo/depo.route";
import { DesignationRouter } from "../modules/Designation/designation.route";
import { InventoryRoute } from "../modules/inventories/inventories.route";
import { JournalRoute } from "../modules/journal/journal.route";
import { LedgerHeadRoute } from "../modules/LedgerHead/LedgerHead.route";
import { OrderRouter } from "../modules/Order/ordet.route";
import { PartyRouter } from "../modules/party/party.route";
import { PosrRoute } from "../modules/post/post.route";
import { ProductRoute } from "../modules/products/product.route";
import { ReportRouter } from "../modules/report/report.route";
import { ReportManagementRouter } from "../modules/ReportManatemenr/report.route";
import { scopeRoute } from "../modules/Scope/scope.route";
import { StakeholderRoute } from "../modules/Stakeholder/stakeholder.route";
import { SubCategoryRouter } from "../modules/SubCategory/subCategory.route";
import { UnitRoute } from "../modules/unit/unit.route";
import { UserRoute } from "../modules/User/user.route";
import { MpoTargetRouter } from "../modules/MpoTarget/target.route";
import { InventoryProgressRoute } from "../modules/InventoryProgress/inventoryProgress.route";

const router = express.Router();

const moduleroutes = [
  {
    path: "/auth",
    route: AuthRoutes,
  },
  {
    path: "/category",
    route: CategoryRouter,
  },
  {
    path: "/sub-category",
    route: SubCategoryRouter,
  },
  {
    path: "/unit",
    route: UnitRoute,
  },
  {
    path: "/product",
    route: ProductRoute,
  },
  {
    path: "/chemist",
    route: ChemistRoute,
  },
  {
    path: "/post",
    route: PosrRoute,
  },
  {
    path: "/user",
    route: UserRoute,
  },
  {
    path: "/depo",
    route: DepoRouter,
  },
  {
    path: "/party",
    route: PartyRouter,
  },
  {
    path: "/ledger_head",
    route: LedgerHeadRoute,
  },
  {
    path: "/account_head",
    route: AccountHeadRoute,
  },
  {
    path: "/journal",
    route: JournalRoute,
  },
  {
    path: "/inventory",
    route: InventoryRoute,
  },
  {
    path: "/degree",
    route: DegreeRouter,
  },
  {
    path: "/designation",
    route: DesignationRouter,
  },
  {
    path: "/stakeholder",
    route: StakeholderRoute,
  },
  {
    path: "/scope",
    route: scopeRoute,
  },
  {
    path: "/order",
    route: OrderRouter,
  },
  {
    path: "/report",
    route: ReportRouter,
  },
  {
    path: "/reportManagement",
    route: ReportManagementRouter,
  },
  {
    path: "/mpoTarget",
    route: MpoTargetRouter,
  },
  {
    path: "/inventoryProgress",
    route: InventoryProgressRoute,
  }
];

moduleroutes.forEach((route) => router.use(route.path, route.route));

export default router;
